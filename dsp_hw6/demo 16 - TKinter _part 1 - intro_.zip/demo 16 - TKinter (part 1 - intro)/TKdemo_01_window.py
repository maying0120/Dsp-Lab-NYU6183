# Minimal Tk demo

import tkinter as Tk 		# If using Python 3
# import Tkinter as Tk 		# If using Python 2

print('Close the tk window to quit')

root = Tk.Tk()      # or 'top'
root.mainloop()
