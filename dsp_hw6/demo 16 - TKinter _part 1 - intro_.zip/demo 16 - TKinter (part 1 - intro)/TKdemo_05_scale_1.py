# TK slider demo: Minimal.
# Does not do anything.

import tkinter as Tk

root = Tk.Tk()

# Define slider
S1 = Tk.Scale(root)

# Place slider
S1.pack()

root.mainloop()

